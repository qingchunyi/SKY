
# ApiResponseobject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**List&lt;Sheet&gt;**](Sheet.md) |  |  [optional]
**head** | [**Head**](Head.md) |  |  [optional]



