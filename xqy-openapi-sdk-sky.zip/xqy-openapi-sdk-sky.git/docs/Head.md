
# Head

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 成功/失败编码 |  [optional]
**messsage** | **String** | 成功/失败信息 |  [optional]
**status** | **String** | 结果状态 |  [optional]



